-- Fix existing users table structure
USE booksdb;

-- Check if name column exists, if not add it
ALTER TABLE users ADD COLUMN IF NOT EXISTS name VARCHAR(255) NOT NULL DEFAULT '';

-- If you have existing users without names, you might want to update them
-- UPDATE users SET name = email WHERE name = '' OR name IS NULL;