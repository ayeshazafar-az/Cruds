const db = require("../db");

// Get all books
exports.getAllBooks = async (req, res) => {
  try {
    const [rows] = await db.query("SELECT * FROM books");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch books", error: err.message });
  }
};

// Get book by ID
exports.getBookById = async (req, res) => {
  try {
    const [rows] = await db.query("SELECT * FROM books WHERE id = ?", [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ message: "Book not found" });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch book", error: err.message });
  }
};

// Add book (requires login)
exports.addBook = async (req, res) => {
  try {
    const { title, author, year } = req.body;
    const [result] = await db.query(
      "INSERT INTO books (title, author, year) VALUES (?, ?, ?)",
      [title, author, year]
    );
    res.status(201).json({ id: result.insertId, title, author, year });
  } catch (err) {
    res.status(500).json({ message: "Failed to add book", error: err.message });
  }
};

// Update book (PUBLIC)
exports.updateBook = async (req, res) => {
  try {
    const { title, author, year } = req.body;
    const [result] = await db.query(
      "UPDATE books SET title = ?, author = ?, year = ? WHERE id = ?",
      [title, author, year, req.params.id]
    );
    if (result.affectedRows === 0)
      return res.status(404).json({ message: "Book not found" });
    res.json({ message: "Book updated successfully", id: req.params.id, title, author, year });
  } catch (err) {
    res.status(500).json({ message: "Failed to update book", error: err.message });
  }
};

// Delete book (requires login)
exports.deleteBook = async (req, res) => {
  try {
    const [result] = await db.query("DELETE FROM books WHERE id = ?", [req.params.id]);
    if (result.affectedRows === 0)
      return res.status(404).json({ message: "Book not found" });
    res.json({ message: "Book deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: "Failed to delete book", error: err.message });
  }
};
