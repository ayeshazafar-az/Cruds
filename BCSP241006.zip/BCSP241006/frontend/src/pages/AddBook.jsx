import React, { useState } from "react";
import { api } from "../api";
import { useNavigate } from "react-router-dom";
import { isLoggedIn } from "../utils/auth";

const AddBook = () => {
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [year, setYear] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const handleAddBook = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    // Check if user is logged in
    if (!isLoggedIn()) {
      setError("You must be logged in to add a book");
      return;
    }

    try {
      await api.post("/books", { title, author, year });

      setSuccess("Book added successfully!");
      setTitle("");
      setAuthor("");
      setYear("");

      // Redirect to books page after short delay
      setTimeout(() => {
        navigate("/books");
      }, 1000);
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || "Failed to add book");
    }
  };

  return (
    <div style={{ 
      padding: "20px", 
      backgroundColor: "#f8f9fa", 
      minHeight: "100vh",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }}>
      <div style={{ 
        backgroundColor: "white", 
        borderRadius: "15px", 
        padding: "40px", 
        boxShadow: "0 8px 25px rgba(0, 0, 0, 0.1)",
        maxWidth: "500px",
        width: "100%",
        margin: "20px"
      }}>
        <h2 style={{ 
          color: "#2c3e50", 
          textAlign: "center", 
          marginBottom: "30px",
          fontSize: "2rem",
          fontWeight: "bold"
        }}>
          ➕ Add New Book
        </h2>

        {error && (
          <div style={{ 
            backgroundColor: "#f8d7da", 
            color: "#721c24", 
            padding: "15px", 
            borderRadius: "8px", 
            marginBottom: "20px",
            border: "1px solid #f5c6cb"
          }}>
            {error}
          </div>
        )}
        
        {success && (
          <div style={{ 
            backgroundColor: "#d4edda", 
            color: "#155724", 
            padding: "15px", 
            borderRadius: "8px", 
            marginBottom: "20px",
            border: "1px solid #c3e6cb"
          }}>
            {success}
          </div>
        )}

        <form onSubmit={handleAddBook} style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          <div>
            <label style={{ 
              display: "block", 
              marginBottom: "8px", 
              fontWeight: "600", 
              color: "#495057",
              fontSize: "16px"
            }}>
              📖 Title:
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "12px 16px",
                border: "2px solid #e9ecef",
                borderRadius: "8px",
                fontSize: "16px",
                transition: "border-color 0.2s ease",
                boxSizing: "border-box"
              }}
              onFocus={(e) => {
                e.target.style.borderColor = "#007bff";
                e.target.style.outline = "none";
              }}
              onBlur={(e) => {
                e.target.style.borderColor = "#e9ecef";
              }}
            />
          </div>

          <div>
            <label style={{ 
              display: "block", 
              marginBottom: "8px", 
              fontWeight: "600", 
              color: "#495057",
              fontSize: "16px"
            }}>
              ✍️ Author:
            </label>
            <input
              type="text"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "12px 16px",
                border: "2px solid #e9ecef",
                borderRadius: "8px",
                fontSize: "16px",
                transition: "border-color 0.2s ease",
                boxSizing: "border-box"
              }}
              onFocus={(e) => {
                e.target.style.borderColor = "#007bff";
                e.target.style.outline = "none";
              }}
              onBlur={(e) => {
                e.target.style.borderColor = "#e9ecef";
              }}
            />
          </div>

          <div>
            <label style={{ 
              display: "block", 
              marginBottom: "8px", 
              fontWeight: "600", 
              color: "#495057",
              fontSize: "16px"
            }}>
              📅 Year:
            </label>
            <input
              type="number"
              value={year}
              onChange={(e) => setYear(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "12px 16px",
                border: "2px solid #e9ecef",
                borderRadius: "8px",
                fontSize: "16px",
                transition: "border-color 0.2s ease",
                boxSizing: "border-box"
              }}
              onFocus={(e) => {
                e.target.style.borderColor = "#007bff";
                e.target.style.outline = "none";
              }}
              onBlur={(e) => {
                e.target.style.borderColor = "#e9ecef";
              }}
            />
          </div>

          <button 
            type="submit"
            style={{ 
              backgroundColor: "#28a745",
              color: "white",
              border: "none",
              padding: "15px 30px",
              borderRadius: "8px",
              fontSize: "18px",
              fontWeight: "600",
              cursor: "pointer",
              boxShadow: "0 4px 15px rgba(40, 167, 69, 0.3)",
              transition: "all 0.3s ease",
              marginTop: "10px"
            }}
            onMouseOver={(e) => {
              e.target.style.backgroundColor = "#218838";
              e.target.style.transform = "translateY(-2px)";
              e.target.style.boxShadow = "0 6px 20px rgba(40, 167, 69, 0.4)";
            }}
            onMouseOut={(e) => {
              e.target.style.backgroundColor = "#28a745";
              e.target.style.transform = "translateY(0)";
              e.target.style.boxShadow = "0 4px 15px rgba(40, 167, 69, 0.3)";
            }}
          >
            📚 Add Book
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddBook;
