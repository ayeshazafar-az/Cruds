import React, { useState } from "react";
import { api } from "../api";
import { useNavigate } from "react-router-dom";
import { setToken } from "../utils/auth";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      setError("Email and password required.");
      return;
    }
    try {
      const res = await api.post("/auth/login", { email, password });
      setToken(res.data.token);
      navigate("/books");
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || "Login failed.");
    }
  };

  return (
    <div style={{ 
      padding: "20px", 
      backgroundColor: "#f8f9fa", 
      minHeight: "100vh",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }}>
      <div style={{ 
        backgroundColor: "white", 
        borderRadius: "15px", 
        padding: "40px", 
        boxShadow: "0 8px 25px rgba(0, 0, 0, 0.1)",
        maxWidth: "450px",
        width: "100%",
        margin: "20px"
      }}>
        <div style={{ textAlign: "center", marginBottom: "30px" }}>
          <h1 style={{ 
            color: "#2c3e50", 
            margin: "0 0 10px 0",
            fontSize: "2.5rem",
            fontWeight: "bold"
          }}>
            🔑 Welcome Back
          </h1>
          <p style={{ 
            color: "#6c757d", 
            margin: 0,
            fontSize: "16px"
          }}>
            Sign in to your account
          </p>
        </div>

        {error && (
          <div style={{ 
            backgroundColor: "#f8d7da", 
            color: "#721c24", 
            padding: "15px", 
            borderRadius: "8px", 
            marginBottom: "20px",
            border: "1px solid #f5c6cb",
            display: "flex",
            alignItems: "center",
            gap: "10px"
          }}>
            <span style={{ fontSize: "18px" }}>⚠️</span>
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          <div>
            <label style={{ 
              display: "block", 
              marginBottom: "8px", 
              fontWeight: "600", 
              color: "#495057",
              fontSize: "16px"
            }}>
              📧 Email Address:
            </label>
            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "12px 16px",
                border: "2px solid #e9ecef",
                borderRadius: "8px",
                fontSize: "16px",
                transition: "border-color 0.2s ease",
                boxSizing: "border-box"
              }}
              onFocus={(e) => {
                e.target.style.borderColor = "#007bff";
                e.target.style.outline = "none";
              }}
              onBlur={(e) => {
                e.target.style.borderColor = "#e9ecef";
              }}
            />
          </div>

          <div>
            <label style={{ 
              display: "block", 
              marginBottom: "8px", 
              fontWeight: "600", 
              color: "#495057",
              fontSize: "16px"
            }}>
              🔒 Password:
            </label>
            <input
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "12px 16px",
                border: "2px solid #e9ecef",
                borderRadius: "8px",
                fontSize: "16px",
                transition: "border-color 0.2s ease",
                boxSizing: "border-box"
              }}
              onFocus={(e) => {
                e.target.style.borderColor = "#007bff";
                e.target.style.outline = "none";
              }}
              onBlur={(e) => {
                e.target.style.borderColor = "#e9ecef";
              }}
            />
          </div>

          <button 
            type="submit"
            style={{ 
              backgroundColor: "#007bff",
              color: "white",
              border: "none",
              padding: "15px 30px",
              borderRadius: "8px",
              fontSize: "18px",
              fontWeight: "600",
              cursor: "pointer",
              boxShadow: "0 4px 15px rgba(0, 123, 255, 0.3)",
              transition: "all 0.3s ease",
              marginTop: "10px"
            }}
            onMouseOver={(e) => {
              e.target.style.backgroundColor = "#0056b3";
              e.target.style.transform = "translateY(-2px)";
              e.target.style.boxShadow = "0 6px 20px rgba(0, 123, 255, 0.4)";
            }}
            onMouseOut={(e) => {
              e.target.style.backgroundColor = "#007bff";
              e.target.style.transform = "translateY(0)";
              e.target.style.boxShadow = "0 4px 15px rgba(0, 123, 255, 0.3)";
            }}
          >
            🚀 Sign In
          </button>
        </form>

        <div style={{ 
          textAlign: "center", 
          marginTop: "30px", 
          paddingTop: "20px",
          borderTop: "1px solid #e9ecef"
        }}>
          <p style={{ 
            color: "#6c757d", 
            margin: "0 0 15px 0",
            fontSize: "14px"
          }}>
            Don't have an account?
          </p>
          <button
            onClick={() => navigate("/register")}
            style={{
              backgroundColor: "transparent",
              color: "#007bff",
              border: "2px solid #007bff",
              padding: "10px 20px",
              borderRadius: "6px",
              fontSize: "16px",
              fontWeight: "600",
              cursor: "pointer",
              transition: "all 0.2s ease"
            }}
            onMouseOver={(e) => {
              e.target.style.backgroundColor = "#007bff";
              e.target.style.color = "white";
            }}
            onMouseOut={(e) => {
              e.target.style.backgroundColor = "transparent";
              e.target.style.color = "#007bff";
            }}
          >
            📝 Create Account
          </button>
        </div>
      </div>
    </div>
  );
};

export default Login;
