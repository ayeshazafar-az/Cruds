import React from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api";
import { isLoggedIn } from "../utils/auth";

const BookCard = ({ book }) => {
  const navigate = useNavigate();
  const loggedIn = isLoggedIn();

  const handleEdit = () => {
    navigate(`/edit-book/${book.id}`);
  };

  const handleDelete = async () => {
    if (!loggedIn) return alert("Login required to delete book");

    try {
      await api.delete(`/books/${book.id}`);
      alert("Book deleted successfully");
      window.location.reload(); // simple reload to refresh books
    } catch (err) {
      console.error(err);
      alert("Failed to delete book");
    }
  };

  return (
    <div style={{ border: "1px solid #ccc", padding: "10px", width: "200px" }}>
      <h3>{book.title}</h3>
      <p><strong>Author:</strong> {book.author}</p>
      <p><strong>Year:</strong> {book.year}</p>

      {loggedIn && (
        <div style={{ marginTop: "10px" }}>
          <button onClick={handleEdit}>Edit</button>
          <button onClick={handleDelete} style={{ marginLeft: "5px" }}>Delete</button>
        </div>
      )}
    </div>
  );
};

export default BookCard;
