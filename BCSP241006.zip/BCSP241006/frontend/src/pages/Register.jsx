import React, { useState } from "react";
import { api } from "../api";
import { useNavigate } from "react-router-dom";

const Register = () => {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    if (!username || !email || !password) {
      setError("All fields are required.");
      return;
    }
    try {
      await api.post("/auth/register", { username, email, password });
      navigate("/login");
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || "Registration failed.");
    }
  };

  return (
    <div style={{ 
      padding: "20px", 
      backgroundColor: "#f8f9fa", 
      minHeight: "100vh",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }}>
      <div style={{ 
        backgroundColor: "white", 
        borderRadius: "15px", 
        padding: "40px", 
        boxShadow: "0 8px 25px rgba(0, 0, 0, 0.1)",
        maxWidth: "500px",
        width: "100%",
        margin: "20px"
      }}>
        <div style={{ textAlign: "center", marginBottom: "30px" }}>
          <h1 style={{ 
            color: "#2c3e50", 
            margin: "0 0 10px 0",
            fontSize: "2.5rem",
            fontWeight: "bold"
          }}>
            📝 Join Us Today
          </h1>
          <p style={{ 
            color: "#6c757d", 
            margin: 0,
            fontSize: "16px"
          }}>
            Create your account to get started
          </p>
        </div>

        {error && (
          <div style={{ 
            backgroundColor: "#f8d7da", 
            color: "#721c24", 
            padding: "15px", 
            borderRadius: "8px", 
            marginBottom: "20px",
            border: "1px solid #f5c6cb",
            display: "flex",
            alignItems: "center",
            gap: "10px"
          }}>
            <span style={{ fontSize: "18px" }}>⚠️</span>
            {error}
          </div>
        )}

        <form onSubmit={handleRegister} style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          <div>
            <label style={{ 
              display: "block", 
              marginBottom: "8px", 
              fontWeight: "600", 
              color: "#495057",
              fontSize: "16px"
            }}>
              👤 Username:
            </label>
            <input
              type="text"
              placeholder="Choose a username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "12px 16px",
                border: "2px solid #e9ecef",
                borderRadius: "8px",
                fontSize: "16px",
                transition: "border-color 0.2s ease",
                boxSizing: "border-box"
              }}
              onFocus={(e) => {
                e.target.style.borderColor = "#007bff";
                e.target.style.outline = "none";
              }}
              onBlur={(e) => {
                e.target.style.borderColor = "#e9ecef";
              }}
            />
          </div>

          <div>
            <label style={{ 
              display: "block", 
              marginBottom: "8px", 
              fontWeight: "600", 
              color: "#495057",
              fontSize: "16px"
            }}>
              📧 Email Address:
            </label>
            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "12px 16px",
                border: "2px solid #e9ecef",
                borderRadius: "8px",
                fontSize: "16px",
                transition: "border-color 0.2s ease",
                boxSizing: "border-box"
              }}
              onFocus={(e) => {
                e.target.style.borderColor = "#007bff";
                e.target.style.outline = "none";
              }}
              onBlur={(e) => {
                e.target.style.borderColor = "#e9ecef";
              }}
            />
          </div>

          <div>
            <label style={{ 
              display: "block", 
              marginBottom: "8px", 
              fontWeight: "600", 
              color: "#495057",
              fontSize: "16px"
            }}>
              🔒 Password:
            </label>
            <input
              type="password"
              placeholder="Create a strong password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "12px 16px",
                border: "2px solid #e9ecef",
                borderRadius: "8px",
                fontSize: "16px",
                transition: "border-color 0.2s ease",
                boxSizing: "border-box"
              }}
              onFocus={(e) => {
                e.target.style.borderColor = "#007bff";
                e.target.style.outline = "none";
              }}
              onBlur={(e) => {
                e.target.style.borderColor = "#e9ecef";
              }}
            />
          </div>

          <button 
            type="submit"
            style={{ 
              backgroundColor: "#28a745",
              color: "white",
              border: "none",
              padding: "15px 30px",
              borderRadius: "8px",
              fontSize: "18px",
              fontWeight: "600",
              cursor: "pointer",
              boxShadow: "0 4px 15px rgba(40, 167, 69, 0.3)",
              transition: "all 0.3s ease",
              marginTop: "10px"
            }}
            onMouseOver={(e) => {
              e.target.style.backgroundColor = "#218838";
              e.target.style.transform = "translateY(-2px)";
              e.target.style.boxShadow = "0 6px 20px rgba(40, 167, 69, 0.4)";
            }}
            onMouseOut={(e) => {
              e.target.style.backgroundColor = "#28a745";
              e.target.style.transform = "translateY(0)";
              e.target.style.boxShadow = "0 4px 15px rgba(40, 167, 69, 0.3)";
            }}
          >
            🎉 Create Account
          </button>
        </form>

        <div style={{ 
          textAlign: "center", 
          marginTop: "30px", 
          paddingTop: "20px",
          borderTop: "1px solid #e9ecef"
        }}>
          <p style={{ 
            color: "#6c757d", 
            margin: "0 0 15px 0",
            fontSize: "14px"
          }}>
            Already have an account?
          </p>
          <button
            onClick={() => navigate("/login")}
            style={{
              backgroundColor: "transparent",
              color: "#28a745",
              border: "2px solid #28a745",
              padding: "10px 20px",
              borderRadius: "6px",
              fontSize: "16px",
              fontWeight: "600",
              cursor: "pointer",
              transition: "all 0.2s ease"
            }}
            onMouseOver={(e) => {
              e.target.style.backgroundColor = "#28a745";
              e.target.style.color = "white";
            }}
            onMouseOut={(e) => {
              e.target.style.backgroundColor = "transparent";
              e.target.style.color = "#28a745";
            }}
          >
            🔑 Sign In
          </button>
        </div>
      </div>
    </div>
  );
};

export default Register;
