import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { isLoggedIn, removeToken } from "../utils/auth";

const Navbar = () => {
  const navigate = useNavigate();
  const loggedIn = isLoggedIn();

  const handleLogout = () => {
    removeToken();
    navigate("/login");
  };

  return (
    <nav style={{ 
      padding: "15px 20px", 
      background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)", 
      display: "flex", 
      gap: "20px", 
      alignItems: "center",
      boxShadow: "0 2px 10px rgba(0, 0, 0, 0.1)",
      marginBottom: "0"
    }}>
      <Link 
        to="/" 
        style={{ 
          color: "white", 
          textDecoration: "none", 
          fontWeight: "600",
          fontSize: "16px",
          padding: "8px 16px",
          borderRadius: "6px",
          transition: "all 0.2s ease"
        }}
        onMouseOver={(e) => {
          e.target.style.backgroundColor = "rgba(255, 255, 255, 0.2)";
        }}
        onMouseOut={(e) => {
          e.target.style.backgroundColor = "transparent";
        }}
      >
        🏠 Home
      </Link>
      <Link 
        to="/books" 
        style={{ 
          color: "white", 
          textDecoration: "none", 
          fontWeight: "600",
          fontSize: "16px",
          padding: "8px 16px",
          borderRadius: "6px",
          transition: "all 0.2s ease"
        }}
        onMouseOver={(e) => {
          e.target.style.backgroundColor = "rgba(255, 255, 255, 0.2)";
        }}
        onMouseOut={(e) => {
          e.target.style.backgroundColor = "transparent";
        }}
      >
        📚 Books
      </Link>
      {!loggedIn && (
        <>
          <Link 
            to="/login" 
            style={{ 
              color: "white", 
              textDecoration: "none", 
              fontWeight: "600",
              fontSize: "16px",
              padding: "8px 16px",
              borderRadius: "6px",
              transition: "all 0.2s ease"
            }}
            onMouseOver={(e) => {
              e.target.style.backgroundColor = "rgba(255, 255, 255, 0.2)";
            }}
            onMouseOut={(e) => {
              e.target.style.backgroundColor = "transparent";
            }}
          >
            🔑 Login
          </Link>
          <Link 
            to="/register" 
            style={{ 
              color: "white", 
              textDecoration: "none", 
              fontWeight: "600",
              fontSize: "16px",
              padding: "8px 16px",
              borderRadius: "6px",
              transition: "all 0.2s ease"
            }}
            onMouseOver={(e) => {
              e.target.style.backgroundColor = "rgba(255, 255, 255, 0.2)";
            }}
            onMouseOut={(e) => {
              e.target.style.backgroundColor = "transparent";
            }}
          >
            📝 Register
          </Link>
        </>
      )}
      {loggedIn && (
        <>
          <Link 
            to="/add-book" 
            style={{ 
              color: "white", 
              textDecoration: "none", 
              fontWeight: "600",
              fontSize: "16px",
              padding: "8px 16px",
              borderRadius: "6px",
              transition: "all 0.2s ease"
            }}
            onMouseOver={(e) => {
              e.target.style.backgroundColor = "rgba(255, 255, 255, 0.2)";
            }}
            onMouseOut={(e) => {
              e.target.style.backgroundColor = "transparent";
            }}
          >
            ➕ Add Book
          </Link>
          <button 
            onClick={handleLogout}
            style={{ 
              backgroundColor: "rgba(220, 53, 69, 0.8)",
              color: "white",
              border: "none",
              padding: "8px 16px",
              borderRadius: "6px",
              cursor: "pointer",
              fontWeight: "600",
              fontSize: "16px",
              transition: "all 0.2s ease",
              marginLeft: "auto"
            }}
            onMouseOver={(e) => {
              e.target.style.backgroundColor = "rgba(220, 53, 69, 1)";
              e.target.style.transform = "translateY(-1px)";
            }}
            onMouseOut={(e) => {
              e.target.style.backgroundColor = "rgba(220, 53, 69, 0.8)";
              e.target.style.transform = "translateY(0)";
            }}
          >
            🚪 Logout
          </button>
        </>
      )}
    </nav>
  );
};

export default Navbar;
