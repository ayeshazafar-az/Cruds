require("dotenv").config();
const express = require("express");
const cors = require("cors");
const { PORT } = require("./config");
const db = require("./db");

const app = express();

// Middlewares
app.use(cors({
  origin: process.env.CORS_ORIGIN || "http://localhost:5173",
  credentials: true,
}));
app.use(express.json());

// Routes
const authRoutes = require("./routes/auth");
const bookRoutes = require("./routes/books");

app.use("/api/auth", authRoutes);
app.use("/api/books", bookRoutes);

// Test server
app.get("/", (req, res) => {
  res.send(
    `<h1>Backend server running</h1>
     <a href="http://localhost:${process.env.PORT || 3000}/api/books">Books</a><br>
     <a href="http://localhost:${process.env.PORT || 3000}/test-db">Test DB</a><br>
     <a href="http://localhost:${process.env.PORT || 3000}/test-users">Test Users Table</a><br>
     <a href="http://localhost:${process.env.PORT || 3000}/api/auth/register">Register</a><br>
     <a href="http://localhost:${process.env.PORT || 3000}/api/auth/login">Login</a>`
  );
});

// Test DB connection
app.get("/test-db", async (req, res) => {
  try {
    const [rows] = await db.query("SELECT 1 + 1 AS result");
    res.json({ message: "DB connected!", result: rows[0].result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Test users table
app.get("/test-users", async (req, res) => {
  try {
    const [users] = await db.query("SELECT COUNT(*) as count FROM users");
    res.json({ message: "Users table accessible", userCount: users[0].count });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 404 handler
app.use((req, res, next) => {
  res.status(404).json({ message: "Route not found" });
});

// Global error handler
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ message: err.message || "Internal server error" });
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`👉 Test server: http://localhost:${PORT}/`);
  console.log(`👉 Test DB: http://localhost:${PORT}/test-db`);
  console.log(`👉 Register: POST http://localhost:${PORT}/api/auth/register`);
  console.log(`👉 Login: POST http://localhost:${PORT}/api/auth/login`);
  console.log(`👉 Books: GET http://localhost:${PORT}/api/books`);
});
