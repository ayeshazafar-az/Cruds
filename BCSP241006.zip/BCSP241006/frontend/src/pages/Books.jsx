import React, { useEffect, useState } from "react";
import { api } from "../api";
import { useNavigate } from "react-router-dom";
import { isLoggedIn } from "../utils/auth";

const Books = () => {
  const [books, setBooks] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const loggedIn = isLoggedIn();

  const fetchBooks = async () => {
    try {
      setLoading(true);
      const res = await api.get("/books"); // public route
      setBooks(res.data);
    } catch (err) {
      console.error(err);
      setError("Failed to fetch books. Check backend server.");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (bookId) => {
    if (!loggedIn) return alert("Login required to delete book");
    
    if (!window.confirm("Are you sure you want to delete this book?")) return;

    try {
      await api.delete(`/books/${bookId}`);
      setBooks(books.filter(book => book.id !== bookId));
      alert("Book deleted successfully");
    } catch (err) {
      console.error(err);
      alert("Failed to delete book");
    }
  };

  const handleEdit = (bookId) => {
    navigate(`/edit-book/${bookId}`);
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  if (loading) {
    return (
      <div style={{ padding: "20px", textAlign: "center" }}>
        <h1>Books</h1>
        <p>Loading books...</p>
      </div>
    );
  }

  return (
    <div style={{ padding: "20px", backgroundColor: "#f8f9fa", minHeight: "100vh" }}>
      <div style={{ 
        backgroundColor: "white", 
        borderRadius: "10px", 
        padding: "30px", 
        boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
        margin: "0 auto",
        maxWidth: "1200px"
      }}>
        <div style={{ 
          display: "flex", 
          justifyContent: "space-between", 
          alignItems: "center", 
          marginBottom: "30px",
          borderBottom: "2px solid #e9ecef",
          paddingBottom: "20px"
        }}>
          <h1 style={{ 
            color: "#2c3e50", 
            margin: 0, 
            fontSize: "2.5rem",
            fontWeight: "bold"
          }}>
            📚 Books Library
          </h1>
          {loggedIn && (
            <button 
              onClick={() => navigate("/add-book")} 
              style={{ 
                backgroundColor: "#28a745",
                color: "white",
                border: "none",
                padding: "12px 24px",
                borderRadius: "8px",
                fontSize: "16px",
                fontWeight: "600",
                cursor: "pointer",
                boxShadow: "0 2px 4px rgba(40, 167, 69, 0.3)",
                transition: "all 0.3s ease"
              }}
              onMouseOver={(e) => {
                e.target.style.backgroundColor = "#218838";
                e.target.style.transform = "translateY(-2px)";
              }}
              onMouseOut={(e) => {
                e.target.style.backgroundColor = "#28a745";
                e.target.style.transform = "translateY(0)";
              }}
            >
              ➕ Add New Book
            </button>
          )}
        </div>

        {error && (
          <div style={{ 
            backgroundColor: "#f8d7da", 
            color: "#721c24", 
            padding: "15px", 
            borderRadius: "8px", 
            marginBottom: "20px",
            border: "1px solid #f5c6cb"
          }}>
            {error}
          </div>
        )}

        {books.length === 0 ? (
          <div style={{ 
            textAlign: "center", 
            padding: "60px 20px",
            color: "#6c757d"
          }}>
            <h3>No books found</h3>
            <p>Start by adding your first book!</p>
          </div>
        ) : (
          <div style={{ 
            overflowX: "auto",
            borderRadius: "8px",
            border: "1px solid #dee2e6"
          }}>
            <table style={{ 
              width: "100%", 
              borderCollapse: "collapse",
              backgroundColor: "white"
            }}>
              <thead>
                <tr style={{ 
                  backgroundColor: "#495057", 
                  color: "white"
                }}>
                  <th style={{ 
                    padding: "15px", 
                    textAlign: "left", 
                    fontWeight: "600",
                    fontSize: "16px",
                    borderBottom: "2px solid #343a40"
                  }}>
                    ID
                  </th>
                  <th style={{ 
                    padding: "15px", 
                    textAlign: "left", 
                    fontWeight: "600",
                    fontSize: "16px",
                    borderBottom: "2px solid #343a40"
                  }}>
                    📖 Title
                  </th>
                  <th style={{ 
                    padding: "15px", 
                    textAlign: "left", 
                    fontWeight: "600",
                    fontSize: "16px",
                    borderBottom: "2px solid #343a40"
                  }}>
                    ✍️ Author
                  </th>
                  <th style={{ 
                    padding: "15px", 
                    textAlign: "left", 
                    fontWeight: "600",
                    fontSize: "16px",
                    borderBottom: "2px solid #343a40"
                  }}>
                    📅 Year
                  </th>
                  {loggedIn && (
                    <th style={{ 
                      padding: "15px", 
                      textAlign: "center", 
                      fontWeight: "600",
                      fontSize: "16px",
                      borderBottom: "2px solid #343a40"
                    }}>
                      ⚙️ Actions
                    </th>
                  )}
                </tr>
              </thead>
              <tbody>
                {books.map((book, index) => (
                  <tr 
                    key={book.id} 
                    style={{ 
                      backgroundColor: index % 2 === 0 ? "#f8f9fa" : "white",
                      transition: "background-color 0.2s ease"
                    }}
                    onMouseOver={(e) => {
                      e.currentTarget.style.backgroundColor = "#e3f2fd";
                    }}
                    onMouseOut={(e) => {
                      e.currentTarget.style.backgroundColor = index % 2 === 0 ? "#f8f9fa" : "white";
                    }}
                  >
                    <td style={{ 
                      padding: "15px", 
                      borderBottom: "1px solid #dee2e6",
                      fontWeight: "500",
                      color: "#495057"
                    }}>
                      #{book.id}
                    </td>
                    <td style={{ 
                      padding: "15px", 
                      borderBottom: "1px solid #dee2e6",
                      fontWeight: "600",
                      color: "#2c3e50",
                      fontSize: "16px"
                    }}>
                      {book.title}
                    </td>
                    <td style={{ 
                      padding: "15px", 
                      borderBottom: "1px solid #dee2e6",
                      color: "#495057",
                      fontSize: "15px"
                    }}>
                      {book.author}
                    </td>
                    <td style={{ 
                      padding: "15px", 
                      borderBottom: "1px solid #dee2e6",
                      color: "#6c757d",
                      fontSize: "15px"
                    }}>
                      {book.year}
                    </td>
                    {loggedIn && (
                      <td style={{ 
                        padding: "15px", 
                        borderBottom: "1px solid #dee2e6",
                        textAlign: "center"
                      }}>
                        <button 
                          onClick={() => handleEdit(book.id)}
                          style={{ 
                            backgroundColor: "#007bff",
                            color: "white",
                            border: "none",
                            padding: "8px 16px",
                            borderRadius: "6px",
                            marginRight: "8px",
                            cursor: "pointer",
                            fontSize: "14px",
                            fontWeight: "500",
                            transition: "all 0.2s ease"
                          }}
                          onMouseOver={(e) => {
                            e.target.style.backgroundColor = "#0056b3";
                            e.target.style.transform = "translateY(-1px)";
                          }}
                          onMouseOut={(e) => {
                            e.target.style.backgroundColor = "#007bff";
                            e.target.style.transform = "translateY(0)";
                          }}
                        >
                          ✏️ Edit
                        </button>
                        <button 
                          onClick={() => handleDelete(book.id)}
                          style={{ 
                            backgroundColor: "#dc3545",
                            color: "white",
                            border: "none",
                            padding: "8px 16px",
                            borderRadius: "6px",
                            cursor: "pointer",
                            fontSize: "14px",
                            fontWeight: "500",
                            transition: "all 0.2s ease"
                          }}
                          onMouseOver={(e) => {
                            e.target.style.backgroundColor = "#c82333";
                            e.target.style.transform = "translateY(-1px)";
                          }}
                          onMouseOut={(e) => {
                            e.target.style.backgroundColor = "#dc3545";
                            e.target.style.transform = "translateY(0)";
                          }}
                        >
                          🗑️ Delete
                        </button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Books;
